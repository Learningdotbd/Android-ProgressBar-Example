package com.ldb.learninddotbd;

import android.app.ProgressDialog;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button button;
    ProgressDialog progress_Bar;
    private int progressBarStatus = 0;
    private Handler progressBarHandler = new Handler();
    private long fileSize = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButtonClick();
    }

    public void addListenerOnButtonClick() {
        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // creating progress bar dialog
                progress_Bar = new ProgressDialog(v.getContext());
                progress_Bar.setCancelable(true);
                progress_Bar.setMessage("File downloading ...");
                progress_Bar.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                progress_Bar.setProgress(0);
                progress_Bar.setMax(100);
                progress_Bar.show();
                //reset progress bar and filesize status-
                progressBarStatus = 0;
                fileSize = 0;

                new Thread(new Runnable() {
                    public void run() {
                        while (progressBarStatus < 100) {
                            // performing operation-
                            progressBarStatus = doOperation();
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            // Updating the progress bar-
                            progressBarHandler.post(new Runnable() {
                                public void run() {
                                    progress_Bar.setProgress(progressBarStatus);
                                }
                            });
                        }
                        // performing operation if file is downloaded,-
                        if (progressBarStatus >= 100) {
                            // sleeping for 1 second after operation completed-
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            // close the progress bar dialog-
                            progress_Bar.dismiss();
                        }
                    }
                }).start();
            }//end of onClick method-
        });
    }

    // checking how much file is downloaded and updating the filesize-
    public int doOperation() {
        //The range of ProgressDialog starts from 0 to 10000-
        while (fileSize <= 10000) {
            fileSize++;
            if (fileSize == 1000) {
                return 10;
            } else if (fileSize == 2000) {
                return 20;
            } else if (fileSize == 3000) {
                return 30;
            } else if (fileSize == 4000) {
                return 40; 
            }

        }//end of while-
        return 100;
    }//end of doOperation-
}
// Thanks for visiting Learning dot bd-